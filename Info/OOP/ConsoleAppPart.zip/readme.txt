﻿Microsoft Visual Studio 2017
----------------------------
Opret et nyt Projekt af typen 'Console App (.NET Framework)' ved navn ConsoleAppParts.

Vælg en ud af to muligheder:

1. mulighed
Luk det nye projekt.
Kopier de to filer fra zip-file til projekt mappen og overskriv dermed den originale Program.cs i projekt.
Åben projektet.
Højre-klik på projektnavnet (ConsoleAppParts - nedenunder Solution) -> Add -> Existing item... (Ctrl+Shift+A)
Vælg Part.cs og klik Add


2. mulighed
Tilføj (Add) en ny klasse ved navn Part (Part.cs)
Åben Part.cs fra zip-filen i notepad eller et lignende tekstbehandlingsprogram og kopier indholdet over i den nye fil i projekt.
Gør det samme med Program-filen (Program.cs)


Projektet er nu klar til test.

